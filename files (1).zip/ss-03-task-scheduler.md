# SS-03：任务调度器 分系统技术规格

> 版本：v1.0 | 分系统编号：SS-03  
> 上游：SS-02（合约/策略）、SS-01（密钥分发）  
> 下游：SS-04（沙箱运行时）、SS-05（输出审查）、SS-06（审计）

---

## 1. 职责边界

| 职责 | 说明 |
|------|------|
| 沙箱节点选择 | 根据安全等级、数据类型、硬件需求（CPU/GPU/TEE）匹配最优节点 |
| 任务生命周期管理 | QUEUED→PREPARING→RUNNING→INSPECTING→COMPLETED/FAILED |
| 资源隔离与限额 | cgroup 资源分配、并发会话上限、GPU 时间配额 |
| 代码预扫描 | 买方提交代码的 AST 静态分析，白名单验证后才放入执行队列 |
| 熔断与超时 | 任务超时强制终止、异常行为实时熔断、节点故障摘除 |
| 队列优先级 | 按合约类型/资源规格/等待时间动态调整执行优先级 |

---

## 2. 数据模型

### 2.1 节点注册表

```sql
CREATE TABLE sandbox_nodes (
    node_id          TEXT PRIMARY KEY,           -- 格式：node-{region}-{seq}
    node_type        TEXT NOT NULL               -- 'tee_sgx'|'tee_sev'|'tee_kp'|'l2_firecracker'|'l3_container'
                     CHECK (node_type IN ('tee_sgx','tee_sev','tee_itrustee','l2_firecracker','l3_container')),
    sandbox_level    TEXT NOT NULL CHECK (sandbox_level IN ('L1','L2','L3')),
    region           TEXT NOT NULL,
    endpoint_grpc    TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'healthy'
                     CHECK (status IN ('healthy','degraded','draining','offline')),

    -- 硬件能力
    cpu_cores_total  INT NOT NULL,
    cpu_cores_avail  INT NOT NULL,
    memory_gb_total  INT NOT NULL,
    memory_gb_avail  INT NOT NULL,
    gpu_count        INT DEFAULT 0,
    gpu_model        TEXT,                       -- 'H100','A100','RTX4090'
    gpu_confidential BOOLEAN DEFAULT FALSE,      -- 支持 NVIDIA CC 模式
    epc_memory_gb    INT DEFAULT 0,              -- SGX EPC 内存
    tee_mrenclave_whitelist TEXT[],              -- 此节点已认证的 MRENCLAVE 列表

    -- 运行时指标
    running_sessions INT DEFAULT 0,
    max_sessions     INT NOT NULL DEFAULT 20,
    cpu_load_pct     INT DEFAULT 0,
    last_heartbeat   TIMESTAMPTZ DEFAULT now(),
    created_at       TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_node_level_status ON sandbox_nodes(sandbox_level, status);
CREATE INDEX idx_node_gpu ON sandbox_nodes(gpu_count, gpu_confidential) WHERE gpu_count > 0;
```

### 2.2 沙箱会话

```sql
CREATE TABLE sandbox_sessions (
    session_id       TEXT PRIMARY KEY,           -- sess-{uuid}
    contract_id      TEXT NOT NULL,
    sandbox_mode     TEXT NOT NULL,
    sandbox_level    TEXT NOT NULL,
    node_id          TEXT REFERENCES sandbox_nodes(node_id),

    -- 买方身份
    consumer_cert_id UUID NOT NULL,
    consumer_org_id  TEXT NOT NULL,

    -- 会话状态
    status           TEXT NOT NULL DEFAULT 'initializing'
                     CHECK (status IN (
                       'initializing','key_distributing','ready',
                       'task_running','suspended','completed','failed','revoked'
                     )),

    -- 资源配置（从合约 PolicyBundle 解析）
    allocated_cpu    INT NOT NULL,
    allocated_mem_gb INT NOT NULL,
    allocated_gpu    INT DEFAULT 0,
    max_runtime_s    INT NOT NULL,

    -- 时间记录
    created_at       TIMESTAMPTZ DEFAULT now(),
    ready_at         TIMESTAMPTZ,
    completed_at     TIMESTAMPTZ,
    expires_at       TIMESTAMPTZ NOT NULL,

    -- 关联
    key_dist_id      UUID,                       -- SS-01 密钥分发记录
    policy_bundle_id UUID NOT NULL,

    metadata         JSONB DEFAULT '{}'
);
```

### 2.3 任务记录

```sql
CREATE TABLE sandbox_tasks (
    task_id          TEXT PRIMARY KEY,           -- task-{uuid}
    session_id       TEXT NOT NULL REFERENCES sandbox_sessions(session_id),
    task_type        TEXT NOT NULL,
    -- 'sql_query'|'python_script'|'model_train'|'model_eval'|'data_transform'
    -- |'app_run'|'llm_sft'|'llm_pretrain'|'vision_train'|'multimodal_train'

    status           TEXT NOT NULL DEFAULT 'queued'
                     CHECK (status IN (
                       'queued','code_scanning','preparing','running',
                       'output_inspecting','completed','failed','cancelled','timed_out'
                     )),
    priority         INT DEFAULT 5,              -- 1（最高）~ 10（最低）

    -- 代码与输入
    code_hash_sm3    TEXT,                       -- 提交代码的 SM3 哈希
    code_scan_result TEXT,                       -- 'pass'|'fail'|'pending'
    code_scan_issues JSONB,                      -- 扫描发现的问题列表
    input_params     JSONB,

    -- 资源使用
    cpu_seconds_used FLOAT DEFAULT 0,
    mem_peak_gb      FLOAT DEFAULT 0,
    gpu_seconds_used FLOAT DEFAULT 0,

    -- 差分隐私
    dp_epsilon_charged FLOAT DEFAULT 0,

    -- 输出
    result_ref       TEXT,                       -- 加密结果存储引用
    result_hash_sm3  TEXT,                       -- 结果完整性校验

    -- 时间
    queued_at        TIMESTAMPTZ DEFAULT now(),
    started_at       TIMESTAMPTZ,
    completed_at     TIMESTAMPTZ,
    timeout_at       TIMESTAMPTZ,

    error_code       TEXT,
    error_message    TEXT
);

CREATE INDEX idx_task_session_status ON sandbox_tasks(session_id, status);
CREATE INDEX idx_task_queued ON sandbox_tasks(status, priority, queued_at)
    WHERE status = 'queued';
```

---

## 3. 状态机

### 3.1 会话状态机

```
INITIALIZING
    │ 合约验证通过 + 节点分配成功
    ▼
KEY_DISTRIBUTING          ← 调用 SS-01 向 TEE 分发密钥
    │ 密钥分发完成（L1: TEE Quote 验证通过；L2: MPC 分片下发）
    ▼
READY                     ← 沙箱就绪，接受任务提交
    │
    ├── [任务提交] ──────→ TASK_RUNNING
    │         └── [任务完成/失败] ──→ READY（继续接受下一任务）
    │
    ├── [DP 预算耗尽] ──→ SUSPENDED
    │         └── [续约] ──────────→ READY
    │
    ├── [expires_at 到达] ──────────→ COMPLETED（清理密钥+内存）
    ├── [主动关闭] ────────────────→ COMPLETED
    ├── [密钥被吊销] ──────────────→ REVOKED（立即终止所有任务）
    └── [节点故障] ────────────────→ FAILED（尝试迁移至备用节点）
```

### 3.2 任务状态机

```
QUEUED
    │ 调度器取出任务
    ▼
CODE_SCANNING             ← AST 静态扫描（≤10s）
    │ 扫描通过
    ▼
PREPARING                 ← 数据加载入 TEE / 环境准备（≤60s）
    │ 准备完成
    ▼
RUNNING                   ← TEE 内执行（受 max_runtime_s 限制）
    │ 执行完成
    ▼
OUTPUT_INSPECTING         ← SS-05 审查结果（≤30s）
    │ 审查通过
    ▼
COMPLETED
    │
    ├── CODE_SCANNING 失败 ──→ FAILED (code_scan_rejected)
    ├── RUNNING 超时 ────────→ TIMED_OUT（强制终止 Enclave）
    ├── RUNNING 异常退出 ────→ FAILED
    ├── OUTPUT_INSPECTING 拒绝 → FAILED (output_rejected)
    └── 用户取消 ────────────→ CANCELLED
```

---

## 4. 节点选择算法

```python
class NodeSelector:
    """
    根据任务需求选择最优沙箱节点
    综合考虑：安全等级、硬件需求、负载均衡、数据亲和性
    """

    def select(self, session_req: SessionRequest) -> SandboxNode:
        # Step 1: 过滤硬性约束
        candidates = self._filter_hard_constraints(session_req)
        if not candidates:
            raise NoSuitableNode(
                f"No node satisfies: level={session_req.min_level}, "
                f"gpu={session_req.gpu_required}, mode={session_req.sandbox_mode}"
            )

        # Step 2: 评分排序
        scored = [(node, self._score(node, session_req)) for node in candidates]
        scored.sort(key=lambda x: x[1], reverse=True)

        # Step 3: 选取最高分（含小随机扰动防热点）
        top_k = scored[:3]
        selected = random.choices(
            [n for n, _ in top_k],
            weights=[s + random.uniform(0, 0.1) for _, s in top_k]
        )[0]

        return selected

    def _filter_hard_constraints(self, req: SessionRequest) -> list[SandboxNode]:
        return db.query("""
            SELECT * FROM sandbox_nodes
            WHERE status = 'healthy'
              AND sandbox_level <= %(min_level)s        -- 等级满足（可向上兼容）
              AND cpu_cores_avail >= %(cpu)s
              AND memory_gb_avail >= %(mem)s
              AND (%(gpu)s = 0 OR (gpu_count >= %(gpu)s
                   AND (NOT %(require_cc)s OR gpu_confidential = TRUE)))
              AND running_sessions < max_sessions
        """, {
            "min_level": req.min_sandbox_level,
            "cpu": req.allocated_cpu,
            "mem": req.allocated_mem_gb,
            "gpu": req.allocated_gpu,
            "require_cc": req.sandbox_mode in GPU_CC_REQUIRED_MODES,
        })

    def _score(self, node: SandboxNode, req: SessionRequest) -> float:
        score = 0.0

        # 负载分（越低越好，权重 40%）
        load_score = (1 - node.running_sessions / node.max_sessions) * 0.4
        score += load_score

        # 安全等级精确匹配分（权重 30%）：避免把高端节点浪费在低安全需求上
        level_map = {"L1": 3, "L2": 2, "L3": 1}
        req_level = level_map[req.min_sandbox_level]
        node_level = level_map[node.sandbox_level]
        level_score = (1 - abs(node_level - req_level) / 3) * 0.3
        score += level_score

        # 同区域亲和分（权重 20%）
        if node.region == req.preferred_region:
            score += 0.2

        # GPU 能力分（训练任务专用，权重 10%）
        if req.allocated_gpu > 0 and node.gpu_confidential:
            score += 0.1

        return score

# GPU 机密计算强制要求的沙箱模式
GPU_CC_REQUIRED_MODES = {
    SandboxMode.UNSTRUCTURED_LLM_SFT,
    SandboxMode.UNSTRUCTURED_LLM_PT,
    SandboxMode.UNSTRUCTURED_VISION,
    SandboxMode.UNSTRUCTURED_MULTIMODAL,
}
```

---

## 5. 代码静态扫描器

```python
class CodeScanner:
    """
    对买方提交的 Python/SQL 代码进行 AST 静态分析
    原则：白名单模式，凡不在允许列表内的操作一律拒绝
    """

    # Python 禁用模块（黑名单，任何导入即拒绝）
    FORBIDDEN_IMPORTS = {
        "os", "sys", "subprocess", "socket", "ctypes", "mmap",
        "multiprocessing", "threading",  # 禁止多进程/线程（防侧信道）
        "pickle", "marshal",              # 禁止序列化（防代码注入）
        "importlib", "__import__",        # 禁止动态导入
        "requests", "urllib", "http",     # 禁止网络访问
        "ftplib", "smtplib", "poplib",
        "tempfile", "shutil",             # 禁止文件系统操作
        "signal", "gc",                   # 禁止底层控制
    }

    # Python 允许模块（白名单）
    ALLOWED_IMPORTS = {
        "numpy", "pandas", "scipy", "sklearn", "xgboost", "lightgbm",
        "torch", "torchvision", "transformers", "datasets", "peft",
        "trl", "accelerate", "deepspeed",               # 训练框架
        "matplotlib", "seaborn", "plotly",              # 可视化
        "json", "re", "math", "datetime", "collections",
        "typing", "dataclasses", "functools", "itertools",
        "sqlalchemy",                                   # DB 操作（沙箱内）
        "diffprivlib", "opacus",                        # DP 库（允许，输出网关会二次检查）
        "PIL", "cv2", "librosa", "torchaudio",          # 多媒体处理
    }

    def scan(self, code: str, language: str, sandbox_mode: SandboxMode) -> ScanResult:
        if language == "python":
            return self._scan_python(code, sandbox_mode)
        elif language == "sql":
            return self._scan_sql(code, sandbox_mode)
        else:
            return ScanResult.FAIL(f"Unsupported language: {language}")

    def _scan_python(self, code: str, mode: SandboxMode) -> ScanResult:
        issues = []
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return ScanResult.FAIL(f"Syntax error: {e}")

        for node in ast.walk(tree):
            # 检测导入
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                module = node.names[0].name.split(".")[0] if isinstance(node, ast.Import) \
                         else (node.module or "").split(".")[0]
                if module in self.FORBIDDEN_IMPORTS:
                    issues.append(Issue("FORBIDDEN_IMPORT", f"Module '{module}' is not allowed", node.lineno))
                elif module not in self.ALLOWED_IMPORTS and module != "":
                    issues.append(Issue("UNKNOWN_IMPORT", f"Module '{module}' is not in whitelist", node.lineno))

            # 检测危险内置函数
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if node.func.id in {"exec", "eval", "compile", "__import__", "open"}:
                        issues.append(Issue("DANGEROUS_BUILTIN", node.func.id, node.lineno))

            # 训练模式：禁止直接文件写入（结果只能通过输出网关）
            if mode in GPU_CC_REQUIRED_MODES:
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Attribute) and node.func.attr in {"save", "save_pretrained"}:
                        # 允许 model.save_pretrained，但目标路径必须是沙箱内预设路径
                        if not self._is_sandbox_output_path(node):
                            issues.append(Issue("INVALID_SAVE_PATH",
                                "save_pretrained must use sandbox output path /sandbox/output/", node.lineno))

        fatal = [i for i in issues if i.severity == "FATAL"]
        return ScanResult.PASS() if not fatal else ScanResult.FAIL(issues=fatal)

    def _scan_sql(self, sql: str, mode: SandboxMode) -> ScanResult:
        """SQL 扫描：基于 sqlparse AST"""
        issues = []
        parsed = sqlparse.parse(sql)
        for stmt in parsed:
            stmt_type = stmt.get_type()
            # 分析模式：仅允许 SELECT
            if mode == SandboxMode.STRUCTURED_QUERY and stmt_type != "SELECT":
                issues.append(Issue("FATAL", f"Only SELECT allowed, got {stmt_type}"))
            # 建模模式：允许 SELECT + CREATE TABLE（沙箱内临时表）
            if mode == SandboxMode.STRUCTURED_MODELING:
                if stmt_type not in {"SELECT", "CREATE", "INSERT"}:
                    issues.append(Issue("FATAL", f"Statement type {stmt_type} not allowed in modeling mode"))
            # 禁止 INTO OUTFILE / LOAD DATA
            if "outfile" in sql.lower() or "load data" in sql.lower():
                issues.append(Issue("FATAL", "File I/O in SQL is forbidden"))
        return ScanResult.PASS() if not issues else ScanResult.FAIL(issues=issues)
```

---

## 6. 熔断与超时管理

```python
class TaskCircuitBreaker:
    """
    双层熔断：任务级（超时）+ 会话级（累积异常）
    """

    def watch_task(self, task: SandboxTask):
        """启动任务监视协程"""
        asyncio.create_task(self._task_watchdog(task))

    async def _task_watchdog(self, task: SandboxTask):
        deadline = task.started_at + timedelta(seconds=task.timeout_s)
        while True:
            await asyncio.sleep(5)
            task = db.refresh(task)

            if task.status in {"completed", "failed", "cancelled"}:
                return  # 正常结束

            if datetime.utcnow() > deadline:
                logger.warning(f"Task {task.task_id} timed out, force killing enclave")
                await sandbox_runtime.force_kill_task(task.task_id)
                db.update(SandboxTask, task.task_id,
                          status="timed_out", error_code="TASK_TIMEOUT")
                audit_service.record(task.session_id, "task_timeout", task.task_id)
                return

            # 异常行为检测（eBPF 上报的 syscall 异常）
            anomalies = ebpf_monitor.get_anomalies(task.task_id)
            if anomalies:
                logger.critical(f"Task {task.task_id} anomaly detected: {anomalies}")
                await sandbox_runtime.force_kill_task(task.task_id)
                db.update(SandboxTask, task.task_id,
                          status="failed", error_code="SECURITY_ANOMALY",
                          error_message=str(anomalies))
                # 会话级熔断：累计异常 ≥3 次，挂起整个会话
                self._check_session_circuit(task.session_id)

    def _check_session_circuit(self, session_id: str):
        count_key = f"anomaly_count:{session_id}"
        count = redis.incr(count_key)
        redis.expire(count_key, 3600)
        if count >= 3:
            logger.critical(f"Session {session_id} circuit breaker triggered")
            db.update(SandboxSession, session_id, status="suspended")
            kms_service.revoke_session_key(session_id)
            notification_service.alert_security_team(session_id, count)
```

---

*文档：SS-03 | 版本：v1.0*
